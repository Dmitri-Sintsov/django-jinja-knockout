LAYOUT_CLASSES = {
    '': {
        'label': 'col-md-3',
        'field': 'col-md-7',
    },
    'display': {
        'label': 'col-md-3 success',
        'field': 'col-md-7 info',
    },
}
