// Import this module to the project to test automatic importmap generation for virtualenv library modules static file finders.

let DjangoDenoSettings = {
    version: '0.1.4',
};

export default DjangoDenoSettings;
