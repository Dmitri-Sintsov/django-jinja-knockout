LAYOUT_CLASSES = {
    '': {
        'label': 'col-md-3',
        'field': 'col-md-7',
    },
    'display': {
        'label': 'w-25 table-info',
        'field': 'w-100 table-light',
    },
}
